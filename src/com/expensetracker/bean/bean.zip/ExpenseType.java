package com.expensetracker.bean;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries( { @NamedQuery(name = "ExpenseType.findAll", query = "select o from ExpenseType o")
    } )
@Table(name="expense_type", schema = "expensedb")
public class ExpenseType implements Serializable {
  private String activeFlg;
  @Column(name = "CREATED")
  private Timestamp created;
  private String defaultFlg;
  private String deletedState;
  @Column(name = "DESCRIPTION")
  private String description;
  @Column(name = "NAME")
  private String name;
  @Id
  @Column(name="ROW_ID", nullable=false)
  private Integer rowId;
  @Column(name = "UPDATED")
  private Timestamp updated;
  private Company company;
  private User user;
  private List<Expenses> expensesList;
  private User user1;

  public ExpenseType() {
  }

  public ExpenseType(String activeFlg, Company company, Timestamp created,
                     User user, String defaultFlg, String deletedState,
                     String description, String name, Integer rowId,
                     Timestamp updated, User user1) {
    this.activeFlg = activeFlg;
    this.company = company;
    this.created = created;
    this.user = user;
    this.defaultFlg = defaultFlg;
    this.deletedState = deletedState;
    this.description = description;
    this.name = name;
    this.rowId = rowId;
    this.updated = updated;
    this.user1 = user1;
  }

  @Column(name="ACTIVE_FLG")
  public String getActiveFlg() {
    return activeFlg;
  }

  public void setActiveFlg(String activeFlg) {
    this.activeFlg = activeFlg;
  }


  public Timestamp getCreated() {
    return created;
  }

  public void setCreated(Timestamp created) {
    this.created = created;
  }


  @Column(name="DEFAULT_FLG")
  public String getDefaultFlg() {
    return defaultFlg;
  }

  public void setDefaultFlg(String defaultFlg) {
    this.defaultFlg = defaultFlg;
  }

  @Column(name="DELETED_STATE")
  public String getDeletedState() {
    return deletedState;
  }

  public void setDeletedState(String deletedState) {
    this.deletedState = deletedState;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

 
  public Integer getRowId() {
    return rowId;
  }

  public void setRowId(Integer rowId) {
    this.rowId = rowId;
  }

  public Timestamp getUpdated() {
    return updated;
  }

  public void setUpdated(Timestamp updated) {
    this.updated = updated;
  }


  @ManyToOne
  @JoinColumn(name = "BU_ID")
  public Company getCompany() {
    return company;
  }

  public void setCompany(Company company) {
    this.company = company;
  }

  @ManyToOne
  @JoinColumn(name = "CREATED_BY")
  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  @OneToMany(mappedBy = "expenseType")
  public List<Expenses> getExpensesList() {
    return expensesList;
  }

  public void setExpensesList(List<Expenses> expensesList) {
    this.expensesList = expensesList;
  }

  public Expenses addExpenses(Expenses expenses) {
    getExpensesList().add(expenses);
    expenses.setExpenseType(this);
    return expenses;
  }

  public Expenses removeExpenses(Expenses expenses) {
    getExpensesList().remove(expenses);
    expenses.setExpenseType(null);
    return expenses;
  }

  @ManyToOne
  @JoinColumn(name = "UPDATED_BY")
  public User getUser1() {
    return user1;
  }

  public void setUser1(User user1) {
    this.user1 = user1;
  }
}
