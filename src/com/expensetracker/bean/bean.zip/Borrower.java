package com.expensetracker.bean;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries( { @NamedQuery(name = "Borrower.findAll", query = "select o from Borrower o")
    } )
@Table(name="borrower", schema = "expensedb")
public class Borrower implements Serializable {
  private String activeFlg;
  @Column(name = "ADDRESS")
  private String address;
  @Column(name = "CREATED")
  private Timestamp created;
  private String defaultFlg;
  private String deletedState;
  @Column(name = "FIRSTNAME")
  private String firstname;
  @Column(name = "LASTNAME")
  private String lastname;
  @Id
  @Column(name="ROW_ID", nullable = false)
  private Integer rowId;
  @Column(name = "UPDATED")
  private Timestamp updated;
  private Company company;
  private User user;
  private User user1;
  private List<Expenses> expensesList;

  public Borrower() {
  }

  public Borrower(String activeFlg, String address, Company company,
                  Timestamp created, User user, String defaultFlg,
                  String deletedState, String firstname, String lastname,
                  Integer rowId, Timestamp updated, User user1) {
    this.activeFlg = activeFlg;
    this.address = address;
    this.company = company;
    this.created = created;
    this.user = user;
    this.defaultFlg = defaultFlg;
    this.deletedState = deletedState;
    this.firstname = firstname;
    this.lastname = lastname;
    this.rowId = rowId;
    this.updated = updated;
    this.user1 = user1;
  }

  @Column(name="ACTIVE_FLG")
  public String getActiveFlg() {
    return activeFlg;
  }

  public void setActiveFlg(String activeFlg) {
    this.activeFlg = activeFlg;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }


  public Timestamp getCreated() {
    return created;
  }

  public void setCreated(Timestamp created) {
    this.created = created;
  }


  @Column(name="DEFAULT_FLG")
  public String getDefaultFlg() {
    return defaultFlg;
  }

  public void setDefaultFlg(String defaultFlg) {
    this.defaultFlg = defaultFlg;
  }

  @Column(name="DELETED_STATE")
  public String getDeletedState() {
    return deletedState;
  }

  public void setDeletedState(String deletedState) {
    this.deletedState = deletedState;
  }

  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public String getLastname() {
    return lastname;
  }

  public void setLastname(String lastname) {
    this.lastname = lastname;
  }


  public Integer getRowId() {
    return rowId;
  }

  public void setRowId(Integer rowId) {
    this.rowId = rowId;
  }

  public Timestamp getUpdated() {
    return updated;
  }

  public void setUpdated(Timestamp updated) {
    this.updated = updated;
  }


  @ManyToOne
  @JoinColumn(name = "BU_ID")
  public Company getCompany() {
    return company;
  }

  public void setCompany(Company company) {
    this.company = company;
  }

  @ManyToOne
  @JoinColumn(name = "CREATED_BY")
  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  @ManyToOne
  @JoinColumn(name = "UPDATED_BY")
  public User getUser1() {
    return user1;
  }

  public void setUser1(User user1) {
    this.user1 = user1;
  }

  @OneToMany(mappedBy = "borrower")
  public List<Expenses> getExpensesList() {
    return expensesList;
  }

  public void setExpensesList(List<Expenses> expensesList) {
    this.expensesList = expensesList;
  }

  public Expenses addExpenses(Expenses expenses) {
    getExpensesList().add(expenses);
    expenses.setBorrower(this);
    return expenses;
  }

  public Expenses removeExpenses(Expenses expenses) {
    getExpensesList().remove(expenses);
    expenses.setBorrower(null);
    return expenses;
  }
}
