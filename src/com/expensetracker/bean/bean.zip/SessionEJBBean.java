package com.expensetracker.bean;


import com.expensetracker.ExpenseTrackerConstants;

import com.expensetracker.util.ExpenseTrackerQueryConstants;

import java.lang.annotation.Annotation;

import java.util.List;

import javax.annotation.Resource;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;
import javax.ejb.Handle;
import javax.ejb.Stateless;

import javax.ejb.TransactionManagement;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless(name = "SessionEJBBean",mappedName = ExpenseTrackerConstants.SESSION_EJB_NAME)
@TransactionManagement 
public class SessionEJBBean implements SessionEJB {
  @PersistenceContext(name = ExpenseTrackerConstants.PERSISTENCE_UNIT_NAME)
      @Resource(name = ExpenseTrackerConstants.SESSION_EJB_NAME)
  private EntityManager em;


  public SessionEJBBean() {
  }

  public Object mergeEntity(Object entity) {
    return em.merge(entity);
  }

  public Object persistEntity(Object entity) {
    em.persist(entity);
    return entity;
  }

  public User VerifyUser(String strUsername, String strPassword) {
    
    Query qry = em.createNamedQuery("VerifyUser"); 
    qry.setParameter("username",strUsername);
    qry.setParameter("password",strPassword);
    
    User u = null;
    try{
        u  = (User) qry.getSingleResult();
    }catch(javax.persistence.NoResultException NRException)
      {
        NRException.printStackTrace();
      }    
    return u;
  }

  public List<Event> getEventList(String userId,String CompanyId) {

    String strQuery = "select * from event where bu_id=" + CompanyId+" and created_by="+userId;
    Query qry = em.createNativeQuery(strQuery, Event.class);
    List<Event> eventList = (List<Event>)qry.getResultList();
    return eventList;
  }

  public List<ExpenseType> getExpenseTypeList(String userId,String CompanyId) {
    String strQuery = "select * from expense_type where bu_id=" + CompanyId+" and created_by="+userId;
    Query qry = em.createNativeQuery(strQuery, ExpenseType.class);
    List<ExpenseType> expenseTypeList = (List<ExpenseType>)qry.getResultList();
    return expenseTypeList;
  }

  public List<User> getUserList(Integer userId,Company comp) {
//    String strQuery = "select *  from User where bu_id=" + CompanyId+" and created_by="+userId;
//    Query qry = em.createNativeQuery(strQuery, User.class);
    Query qry = em.createQuery(ExpenseTrackerQueryConstants.qryFindAllUsers);
    qry.setParameter("createdby", userId); 
    qry.setParameter("company", comp);
    List<User> userList = (List<User>)qry.getResultList();
    return userList;

  }

  public List<PaymentMode> getPaymentModeList(String userId,String CompanyId) {
    String strQuery = "select * from payment_mode where bu_id=" + CompanyId+" and created_by="+userId;
    Query qry = em.createNativeQuery(strQuery, PaymentMode.class);
    List<PaymentMode> paymentModeList = (List<PaymentMode>)qry.getResultList();
    return paymentModeList;

  }

  public List<Expenses> getExpensesList(Integer userId,Company comp) {
   // String strQuery = "select * from expenses where bu_id=" + CompanyId+" and created_by="+userId;
    //Query qry = em.createNativeQuery(strQuery, Expenses.class);
    Query qry = em.createQuery(ExpenseTrackerQueryConstants.qryFindAllExpenses);
    qry.setParameter("createdby",userId); 
    qry.setParameter("company",comp);  
    
    
    List<Expenses> expensesList = (List<Expenses>)qry.getResultList();
    return expensesList;
  }

  public List<Borrower> getBorrowerList(String userId,String CompanyId) {
    String strQuery = "select * from borrower where bu_id=" + CompanyId+" and created_by="+userId;
    Query qry = em.createNativeQuery(strQuery, Borrower.class);
    List<Borrower> borrowerList = (List<Borrower>)qry.getResultList();
    return borrowerList;
  }

  public List<Company> getCompanyList(String Admin) throws IllegalAccessException {

    IllegalAccessException e = null;

    if ((Admin == null) || (Admin.compareTo("Admin") != 0))
      throw e;

    String strQuery =
      "select * from Company where primary_contact='" + Admin + "'";
    Query qry = em.createNativeQuery(strQuery, Company.class);
    List<Company> companyList = (List<Company>)qry.getResultList();
    return companyList;
  }


  public boolean AddObject(Object obj) {
    try {
      
     // EntityManagerFactory EMF = Persistence.createEntityManagerFactory(ExpenseTrackerConstants.PERSISTENCE_UNIT_NAME);
      //em = EMF.createEntityManager(); 
      
    //  em.getTransaction().begin();
      em.persist(obj);
      //em.getTransaction().commit();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return true;

  }


  public boolean AddBorrower(Borrower brr) {
    AddObject(brr);
    return true;
  }


  public boolean AddEvent(Event event) {
    AddObject(event);
    return true;
  }


  public boolean AddExpenseType(ExpenseType expensetype) {
    AddObject(expensetype);
    return true;
  }

  public boolean AddExpenses(Expenses expenses) {
    AddObject(expenses);
    return true;
  }

  public boolean AddCompany(Company company) {
    AddObject(company);
    return true;
  }

  public boolean AddUser(User user) {
    System.out.println("\n\n\nInside AddUser");
    AddObject(user);
    return true;
  }

  public boolean AddPaymentMode(PaymentMode paymentmode) {
    AddObject(paymentmode);
    return true;
  }


    public void create() {
    }

    public Class value() {
        return null;
    }

    public Class<? extends Annotation> annotationType() {
        return null;
    }

    public EJBHome getEJBHome() {
        return null;
    }

    public Object getPrimaryKey() {
        return null;
    }

    public void remove() {
    }

    public Handle getHandle() {
        return null;
    }

    public boolean isIdentical(EJBObject ejbObject) {
        return false;
    }

  public User getUser(String UserId, String CompanyId) {
    
    String strQuery = "select * from User where bu_id=" + CompanyId +" and row_id = " + UserId;
    Query qry = em.createNativeQuery(strQuery, User.class);
    User u = (User)qry.getSingleResult(); 
    return u; 
        
  }
}
